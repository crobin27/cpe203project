import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class AStarPathingStrategy
        implements PathingStrategy
{


    public List<Point> computePath(Point start, Point end,
                                   Predicate<Point> canPassThrough,
                                   BiPredicate<Point, Point> withinReach,
                                   Function<Point, Stream<Point>> potentialNeighbors)
    {
        //Linkedlist datastructure to hold final path
        LinkedList<Point> path = new LinkedList<Point>();

        //Criteria for priority queue
        Comparator<Node> order = (n1, n2) -> n1.getF()- n2.getF();
        Comparator<Node> breakTie = (n1, n2) -> n1.getG() - n2.getG(); //Want smallest distance travelled to break tie

        //Open & Closed list data structure
        PriorityQueue<Node> openList = new PriorityQueue<>(order.thenComparing(breakTie)); //efficiently find smallest F value
        HashMap<Point, Node> openHash = new HashMap<>();   //Efficiently search if contains point/node
        HashMap<Point, Node> closedList = new HashMap<>();
        //For open list, want to grab the best F value (LECTURE HINTS)
            //Priority queue & hashmap (open list)
        //Closed List?
            //Hash maps (quick look up)


        //Add start node to the open list and mark it as the current node
        Node current = new Node(start, 0, calcH(start, end), calcH(start, end), false, null);
        openList.add(current); //Add first node
        openHash.put(start, current);


        while (!withinReach.test(current.getPoint(), end)) //Repeat until a path to the end is found.
        {
            List<Point> validNeighbors = potentialNeighbors.apply(current.getPoint())   //Creates iterable list of the valid neighbors of current node
                    .filter(canPassThrough)                                             //Analyze all valid adjacent nodes
                    .filter((point) -> !closedList.containsKey(point))                  //Analyze nodes that are not on the closed list
                    .collect(Collectors.toList());                                      //Turns it into list to make it iterable
            for (Point adjacent: validNeighbors)    //Iterate through each valid neighbor
            {
                int adjacentG = current.getG() + 1; //Determine distance from start node (g value)
                if (!openHash.containsKey(adjacent))  //Add to Open List if not already in it (Create node for it)
                {
                    //Add node to open list with g & f value
                    Node adjacentNode = new Node(adjacent, adjacentG, calcH(adjacent, end), calcF(current, adjacent, end), true, current);
                    openList.add(adjacentNode);
                    openHash.put(adjacent, adjacentNode);
                }
                else    //If creating point/node in openlist, won't be previous point/node to compare G value to
                {

                    Node oldPath = openHash.get(adjacent); //Get previously calculated path to point/node

                    if (oldPath.getG() > adjacentG) //If the calculated g value is better than a previously calculated g value
                    {
                        //Remove old path from priority queue
                        openList.remove(oldPath);

                        //estimate distance of adjacent node to the end point (h), ii. Add g and h to get an f value, iii. Mark the adjacent node’s prior vertex as the current node
                        Node adjacentNode = new Node(adjacent, adjacentG, calcH(adjacent, end), calcF(current, adjacent, end), true, current);
                        openList.add(adjacentNode);
                        openHash.put(adjacent, adjacentNode);
                    }
                }
            }

            closedList.put(current.getPoint(), current); // Move the current node to the closed list

            if (openList.peek() == null) //Case if no path is to be found
                return path;

            //Choose a node from the open list with the smallest f value and make it the current node
            current = openList.remove();    //Reduces cases of points with equal f values
            openHash.remove(current.getPoint());
        }

        //Rebuild path now that path was found
        while (!(current.getPrevious() == null))
        {
            path.add(current.getPoint());
            current = current.getPrevious();
        }

        //Reverse path to make it in order
        Collections.reverse(path);
        return path;
    }

    public int calcH(Point current, Point end) //Heuristic Distance (h)
    {
        int x = Math.abs(end.x - current.x);
        int y = Math.abs(end.y - current.y);
        return x + y;
    }

    public int calcF(Node currentNode, Point current, Point end)
    {
        return currentNode.getG() + 1 + calcH(current, end);
    }
    //For open list, want to grab the best F value
        //Priority queue & hashmap (open list)
    //Closed List?
        //Hash maps (quick look up)
}
