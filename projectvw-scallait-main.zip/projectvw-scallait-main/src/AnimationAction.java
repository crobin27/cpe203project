import processing.core.PImage;

import java.util.List;

public abstract class AnimationAction extends ExecuteActivities {

    private int animationPeriod;

    public AnimationAction(Point position,
                           List<PImage> images,
                           int imageIndex,
                           int actionPeriod,
                           int animationPeriod)
    {
        super(position, images, imageIndex, actionPeriod);
        this.animationPeriod = animationPeriod;
    }

    protected Action createAnimationAction(int repeatCount) {
        return new Animation(this, repeatCount);
    }

    protected int getAnimationPeriod() { return this.animationPeriod; }

    protected void nextImage() {
        this.setImageIndex( (this.getImageIndex() + 1) % this.getImages().size() ); //Sets new image index
    }
}
