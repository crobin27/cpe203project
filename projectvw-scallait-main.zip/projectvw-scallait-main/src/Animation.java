public class Animation implements Action{
        private AnimationAction entity;
        private int repeatCount;

        public Animation(
                AnimationAction entity,
                int repeatCount) {
            this.entity = entity;
            this.repeatCount = repeatCount;
        }

        public void executeAction(EventScheduler scheduler)
        {
            entity.nextImage();
            if (this.repeatCount != 1)
            {
                scheduler.scheduleEvent(this.entity,
                        this.entity.createAnimationAction(     //Might have to downcast as well
                                Math.max(this.repeatCount - 1,
                                        0)),
                        entity.getAnimationPeriod());  //Might have to downcast
            }
        }
}
