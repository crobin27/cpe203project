import processing.core.PImage;

import java.util.List;

public abstract class Entity{

    private Point position;
    private List<PImage> images;
    private int imageIndex;

    public Entity(Point position, List<PImage> images, int imageIndex)
    {
        this.position = position;
        this.images = images;
        this.imageIndex = imageIndex;
    }
    protected Point getPosition() {return this.position; }

    protected void setPosition(Point pos)  { this.position = pos; }

    protected int getImageIndex() { return this.imageIndex; }

    protected void setImageIndex(int newIndex) { this.imageIndex = newIndex; }

    protected List<PImage> getImages() { return this.images; }

    protected PImage getCurrentImage() { return this.images.get(this.imageIndex); }
}