import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import processing.core.PImage;

public final class Blacksmith extends Entity
{
    public Blacksmith(Point position, List<PImage> images)
    {
        super(position, images, 0);
    }
}
