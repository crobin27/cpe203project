public final class Activity implements Action {
        private final ExecuteActivities entity;
        private final WorldModel world;
        private final ImageStore imageStore;

        public Activity(
                ExecuteActivities entity,
                WorldModel world,
                ImageStore imageStore)
        {
            this.entity = entity; //Entity with executable activity
            this.world = world;
            this.imageStore = imageStore;

        }

        public void executeAction(EventScheduler scheduler) //Replace with general call on ExecuteActivity
        {   this.entity.executeActivity(this.world, this.imageStore, scheduler); }
}
