import java.util.ArrayList;
import java.util.List;

public class Node {

    private Point point;
    private boolean visited;
    private int g;
    private int h;
    private int f;
    private Node previous;

    public Node(Point point, int g, int h, int f, boolean valid, Node previous)
    {
        this.point = point;
        this.g = g;
        this.h = h;
        this.f = f;
        this.visited = valid;
        this.previous = previous;
    }

    public int getG() { return this.g; }
    public int getH() { return this.h; }
    public int getF() { return this.f; }
    public boolean getValid() { return this.visited; }
    public void setVisited() {this.visited = true; }
    public Node getPrevious() { return this.previous; }
    public Point getPoint() { return this.point; }

    @Override
    public String toString() {
        return "Node{" +
                "point=" + point +
                '}';
    }
}
