import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class Alien extends Movable { //movable probably

    private final String QUAKE_KEY = "quake";
    //private PathingStrategy strategy = new SingleStepPathingStrategy();
    private PathingStrategy strategy = new AStarPathingStrategy();
    private int asteroidKillerCounter = 0;

    public Alien(
            Point position,
            List<PImage> images,
            int actionPeriod,
            int animationPeriod) {
        super(position, images, 0, actionPeriod, animationPeriod);

    }

    protected Point nextPosition(
            WorldModel world, Point destPos)
    {
        List<Point> points;

        points = strategy.computePath(this.getPosition(), destPos,
                p -> ( !(p.equals(destPos) || (world.getOccupant(p).isPresent() && !(!(Vein.class).isInstance(world.getOccupant(p).get())))) && world.withinBounds(p) ),
                (p1, p2) -> neighbors(p1, p2),
                PathingStrategy.CARDINAL_NEIGHBORS);
        //return single point
        //Return original point if null
        if (points.isEmpty() )
            return this.getPosition();

        return points.get(0);
    }
/*
    public boolean moveTo(
            WorldModel world,
            Entity target,
            EventScheduler scheduler) {
        if (this.getPosition().adjacent(target.getPosition())) {
            world.removeEntity(target);
            scheduler.unscheduleAllEvents(target);
            return true;
        } else {
            Point nextPos = this.nextPosition(world, target.getPosition() );

            if (!this.getPosition().equals(nextPos)) {
                Optional<Entity> occupant = world.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }
*/
    public void executeActivity(
            WorldModel world,
            ImageStore imageStore,
            EventScheduler scheduler)
    {
        Optional<Entity> AlienTarget =
                findNearest(world, this.getPosition(), Obstacle.class); //this finds nearest asteroid
        long nextPeriod = this.getActionPeriod();

        if (AlienTarget.isPresent()) {
            Point tgtPos = AlienTarget.get().getPosition();

            if (this.moveTo(world, AlienTarget.get(), scheduler)) {
                Quake quake = EntityFactory.createQuake(tgtPos,
                        imageStore.getImageList(QUAKE_KEY));

                world.addEntity(quake);
                nextPeriod += this.getActionPeriod();
                quake.scheduleActions(scheduler, world, imageStore);



                if (asteroidKillerCounter == 5) {
                    world.removeEntity(quake);
                    Vein vein = EntityFactory.createVein(tgtPos, 20000, imageStore.getImageList(LoadWorld.VEIN_KEY));
                    world.addEntity(vein);
                    vein.scheduleActions(scheduler, world, imageStore);
                    this.asteroidKillerCounter = 0;
                }
                else
                    //world.removeEntity(quake);
                    this.asteroidKillerCounter++;
            }
        }

        scheduler.scheduleEvent(this,
                this.createActivityAction(world, imageStore),
                nextPeriod);
    }
    
}
