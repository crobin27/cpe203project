import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public abstract class Miner extends Movable{

    private int resourceLimit;
    private int resourceCount;

    //private PathingStrategy strategy = new SingleStepPathingStrategy();
    private PathingStrategy strategy = new AStarPathingStrategy();

    public Miner(Point position, List<PImage> images, int imageIndex, int actionPeriod, int animationPeriod, int resourceLimit, int resourceCount)
    {
        super(position, images, imageIndex, actionPeriod, animationPeriod);
        this.resourceLimit = resourceLimit;
        this.resourceCount = resourceCount;
    }

    protected int getResourceLimit() { return this.resourceLimit; }

    protected int getResourceCount() {return this.resourceCount; }

    protected void setResourceCount(int newResourceCount) {this.resourceCount = newResourceCount; }

    public boolean moveTo(
            WorldModel world,
            Entity target,
            EventScheduler scheduler)
    {
        if (adjacent(this.getPosition(), target.getPosition())) {
            if (MinerNotFull.class.isInstance(this))
            {
                this.setResourceCount(this.getResourceCount() + 1);
                world.removeEntity(target);
                scheduler.unscheduleAllEvents(target);
            }
            return true;
        }
        else {
            Point nextPos = this.nextPosition(world, target.getPosition());

            if (!this.getPosition().equals(nextPos)) {
                Optional<Entity> occupant = world.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                world.moveEntity(this, nextPos);
            }
            return false;
        }
    }

    protected Point nextPosition(
            WorldModel world, Point destPos)
    {
        List<Point> points;
        //System.out.println("test");
        points = strategy.computePath(this.getPosition(), destPos,
                p -> !(world.isOccupied(p) || p.equals(destPos)) && world.withinBounds(p),
                (p1, p2) -> neighbors(p1, p2),
                PathingStrategy.CARDINAL_NEIGHBORS);
        //return single point
        //Return original point if null
        if (points.isEmpty() )
        {
            return this.getPosition();
        }

        return points.get(0);
    }

    /*
    protected Point nextPosition(
            WorldModel world, Point destPos)
    {   //Should not have to changes this when implementing A* (Just have to change instance variable at top)
        int horiz = Integer.signum(destPos.x - this.getPosition().x);
        Point newPos = new Point(this.getPosition().x + horiz, this.getPosition().y);

        if (horiz == 0 || world.isOccupied(newPos)) {
            int vert = Integer.signum(destPos.y - this.getPosition().y);
            newPos = new Point(this.getPosition().x, this.getPosition().y + vert);

            if (vert == 0 || world.isOccupied(newPos)) {
                newPos = this.getPosition();
            }
        }
        return newPos;
        //computePath(this.getPosition(), desPos)
    }
    //protected abstract boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore);
    */
}
