public interface Action
{
    void executeAction(EventScheduler eventscheduler);
}