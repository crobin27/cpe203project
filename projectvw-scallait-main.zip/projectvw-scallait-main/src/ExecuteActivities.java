import processing.core.PImage;

import java.util.List;

public abstract class ExecuteActivities extends Entity{

    private int actionPeriod;

    public ExecuteActivities(Point position,
                             List<PImage> images,
                             int imageIndex,
                             int actionPeriod)
    {
        super(position, images, imageIndex);
        this.actionPeriod = actionPeriod;
    }
    protected int getActionPeriod() { return this.actionPeriod; }

    protected Action createActivityAction(WorldModel world, ImageStore imageStore)
    {
        return new Activity(this, world, imageStore);
    }

    protected void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore)
    {
        scheduler.scheduleEvent(this,
                this.createActivityAction(world, imageStore),
                this.actionPeriod);
    }

    protected abstract void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler);

}
